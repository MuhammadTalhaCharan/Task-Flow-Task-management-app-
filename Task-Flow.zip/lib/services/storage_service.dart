import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:task_manager/models/task_model.dart';

class StorageService {
  static const String _tasksKey = 'tasks';
  static const String _isDarkModeKey = 'is_dark_mode';
  static StorageService? _instance;
  SharedPreferences? _prefs;

  StorageService._internal();

  static Future<StorageService> getInstance() async {
    if (_instance == null) {
      _instance = StorageService._internal();
      await _instance!._init();
    }
    return _instance!;
  }

  Future<void> _init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  Future<void> saveTasks(List<Task> tasks) async {
    if (_prefs == null) await _init();
    final tasksJson = tasks.map((task) => task.toJson()).toList();
    await _prefs!.setString(_tasksKey, jsonEncode(tasksJson));
  }

  List<Task> getTasks() {
    if (_prefs == null) {
      // Return empty list if not initialized
      return [];
    }
    final tasksString = _prefs!.getString(_tasksKey);
    if (tasksString == null) return [];

    final tasksJson = jsonDecode(tasksString) as List;
    return tasksJson.map((json) => Task.fromJson(json)).toList();
  }

  Future<void> saveThemeMode(bool isDarkMode) async {
    if (_prefs == null) await _init();
    await _prefs!.setBool(_isDarkModeKey, isDarkMode);
  }

  bool getThemeMode() {
    if (_prefs == null) return false;
    return _prefs!.getBool(_isDarkModeKey) ?? false;
  }

  Future<void> clearAllData() async {
    if (_prefs == null) await _init();
    await _prefs!.remove(_tasksKey);
  }
}
