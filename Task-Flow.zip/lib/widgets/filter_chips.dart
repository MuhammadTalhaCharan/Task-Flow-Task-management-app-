import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:task_manager/providers/task_provider.dart';

class FilterChips extends StatelessWidget {
  const FilterChips({super.key});

  final List<String> _filters = const [
    'All',
    'Completed',
    'Pending',
    'High Priority',
  ];

  final List<String> _sortOptions = const [
    'Date',
    'Priority',
    'Alphabetical',
  ];

  @override
  Widget build(BuildContext context) {
    return Consumer<TaskProvider>(
      builder: (context, taskProvider, child) {
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              ..._filters.map((filter) => _buildFilterChip(
                    filter,
                    taskProvider.selectedFilter == filter,
                    () => taskProvider.setFilter(filter),
                  )),
              const SizedBox(width: 8),
              Container(
                width: 1,
                height: 24,
                color: Colors.grey[300],
              ),
              const SizedBox(width: 8),
              ..._sortOptions.map((sort) => _buildSortChip(
                    sort,
                    taskProvider.selectedSort == sort,
                    () => taskProvider.setSort(sort),
                  )),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFilterChip(String label, bool selected, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onTap(),
        showCheckmark: false,
        backgroundColor: Colors.grey.withOpacity(0.1),
        selectedColor: Colors.blue.withOpacity(0.2),
        labelStyle: TextStyle(
          color: selected ? Colors.blue : Colors.grey[700],
          fontWeight: selected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }

  Widget _buildSortChip(String label, bool selected, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ActionChip(
        label: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              selected ? Icons.sort : Icons.sort_outlined,
              size: 16,
              color: selected ? Colors.blue : Colors.grey[600],
            ),
            const SizedBox(width: 4),
            Text(label),
          ],
        ),
        onPressed: onTap,
        backgroundColor: selected
            ? Colors.blue.withOpacity(0.1)
            : Colors.grey.withOpacity(0.1),
        labelStyle: TextStyle(
          color: selected ? Colors.blue : Colors.grey[600],
        ),
      ),
    );
  }
}
