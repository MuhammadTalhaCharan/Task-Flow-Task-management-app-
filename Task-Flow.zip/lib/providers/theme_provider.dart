import 'package:flutter/material.dart';
import 'package:task_manager/services/storage_service.dart';

class ThemeProvider extends ChangeNotifier {
  bool _isDarkMode = false;
  StorageService? _storageService;

  bool get isDarkMode => _isDarkMode;
  ThemeMode get themeMode => _isDarkMode ? ThemeMode.dark : ThemeMode.light;

  ThemeProvider() {
    _initializeTheme();
  }

  Future<void> _initializeTheme() async {
    _storageService = await StorageService.getInstance();
    _isDarkMode = _storageService!.getThemeMode();
    notifyListeners();
  }

  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    _storageService?.saveThemeMode(_isDarkMode);
    notifyListeners();
  }
}
