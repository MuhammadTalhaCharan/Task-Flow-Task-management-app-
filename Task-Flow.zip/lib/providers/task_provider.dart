import 'package:flutter/material.dart';
import 'package:task_manager/models/task_model.dart';
import 'package:task_manager/models/task_priority.dart';
import 'package:task_manager/services/storage_service.dart';

class TaskProvider extends ChangeNotifier {
  List<Task> _tasks = [];
  List<Task> _filteredTasks = [];
  String _searchQuery = '';
  String _selectedFilter = 'All';
  String _selectedSort = 'Date';

  List<Task> get tasks => _filteredTasks;
  List<Task> get allTasks => _tasks;
  String get searchQuery => _searchQuery;
  String get selectedFilter => _selectedFilter;
  String get selectedSort => _selectedSort;

  StorageService? _storageService;

  TaskProvider() {
    _initializeStorage();
  }

  Future<void> _initializeStorage() async {
    _storageService = await StorageService.getInstance();
    await loadTasks();
  }

  // Load tasks from storage
  Future<void> loadTasks() async {
    if (_storageService == null) return;
    _tasks = _storageService!.getTasks();
    _applyFiltersAndSort();
    notifyListeners();
  }

  // Save tasks to storage
  Future<void> _saveTasks() async {
    if (_storageService == null) return;
    await _storageService!.saveTasks(_tasks);
  }

  // Add Task
  Future<void> addTask(Task task) async {
    _tasks.insert(0, task);
    await _saveTasks();
    _applyFiltersAndSort();
    notifyListeners();
  }

  // Delete Task
  Future<void> deleteTask(String taskId) async {
    _tasks.removeWhere((task) => task.id == taskId);
    await _saveTasks();
    _applyFiltersAndSort();
    notifyListeners();
  }

  // Update Task
  Future<void> updateTask(Task updatedTask) async {
    final index = _tasks.indexWhere((task) => task.id == updatedTask.id);
    if (index != -1) {
      _tasks[index] = updatedTask;
      await _saveTasks();
      _applyFiltersAndSort();
      notifyListeners();
    }
  }

  // Mark Complete
  Future<void> toggleTaskCompletion(String taskId) async {
    final index = _tasks.indexWhere((task) => task.id == taskId);
    if (index != -1) {
      final task = _tasks[index];
      _tasks[index] = task.copyWith(isCompleted: !task.isCompleted);
      await _saveTasks();
      _applyFiltersAndSort();
      notifyListeners();
    }
  }

  // Undo Delete - Store deleted task temporarily
  Task? _deletedTask;
  Task? get deletedTask => _deletedTask;

  Future<void> deleteTaskWithUndo(String taskId) async {
    final index = _tasks.indexWhere((task) => task.id == taskId);
    if (index != -1) {
      _deletedTask = _tasks[index];
      _tasks.removeAt(index);
      await _saveTasks();
      _applyFiltersAndSort();
      notifyListeners();
    }
  }

  Future<void> undoDelete() async {
    if (_deletedTask != null) {
      _tasks.insert(0, _deletedTask!);
      _deletedTask = null;
      await _saveTasks();
      _applyFiltersAndSort();
      notifyListeners();
    }
  }

  // Filter Tasks
  void setFilter(String filter) {
    _selectedFilter = filter;
    _applyFiltersAndSort();
    notifyListeners();
  }

  // Search Tasks
  void setSearchQuery(String query) {
    _searchQuery = query;
    _applyFiltersAndSort();
    notifyListeners();
  }

  // Sort Tasks
  void setSort(String sort) {
    _selectedSort = sort;
    _applyFiltersAndSort();
    notifyListeners();
  }

  // Apply Filters and Sort
  void _applyFiltersAndSort() {
    var filteredList = List<Task>.from(_tasks);

    // Apply Search
    if (_searchQuery.isNotEmpty) {
      filteredList = filteredList
          .where((task) =>
              task.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
              task.description
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase()) ||
              task.category.toLowerCase().contains(_searchQuery.toLowerCase()))
          .toList();
    }

    // Apply Filter
    switch (_selectedFilter) {
      case 'Completed':
        filteredList = filteredList.where((task) => task.isCompleted).toList();
        break;
      case 'Pending':
        filteredList = filteredList.where((task) => !task.isCompleted).toList();
        break;
      case 'High Priority':
        filteredList = filteredList
            .where((task) => task.priority == TaskPriority.high)
            .toList();
        break;
      default:
        break;
    }

    // Apply Sort
    switch (_selectedSort) {
      case 'Date':
        filteredList.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        break;
      case 'Priority':
        filteredList
            .sort((a, b) => b.priority.index.compareTo(a.priority.index));
        break;
      case 'Alphabetical':
        filteredList.sort(
            (a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
        break;
    }

    _filteredTasks = filteredList;
  }

  // Dashboard Statistics
  int get totalTasks => _tasks.length;
  int get completedTasks => _tasks.where((task) => task.isCompleted).length;
  int get pendingTasks => _tasks.where((task) => !task.isCompleted).length;
  double get completionProgress =>
      totalTasks > 0 ? completedTasks / totalTasks : 0.0;

  // Clear all tasks
  Future<void> clearAllTasks() async {
    _tasks.clear();
    await _saveTasks();
    _applyFiltersAndSort();
    notifyListeners();
  }
}
